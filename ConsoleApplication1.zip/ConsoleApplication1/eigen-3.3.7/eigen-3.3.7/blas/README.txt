
This directory contains a BLAS library built on top of Eigen.

This module is not built by default. In order to compile it, you need to
type 'make blas' from within your build dir.

