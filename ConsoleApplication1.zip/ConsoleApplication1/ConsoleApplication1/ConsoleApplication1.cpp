// vanila neural network for xor solving using eigen library - for education purpose;

#include "SimpleXorNet_Eigen.h"

int main()
{
	anet.run();

	system("pause");

    return 0;
}
